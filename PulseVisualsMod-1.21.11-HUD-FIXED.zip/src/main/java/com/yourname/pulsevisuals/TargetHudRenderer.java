package com.yourname.pulsevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

public final class TargetHudRenderer implements HudRenderCallback {
    @Override public void onHudRender(DrawContext c, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        float s = SettingsScreen.scale();
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int accent = SettingsScreen.accent();

        if (SettingsScreen.isEnabled("targetHud") && mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity target && target != mc.player) {
            int w = (int)(205*s), h = (int)(64*s), x = sw/2 + (int)(34*s), y = sh/2 - (int)(47*s);
            card(c,x,y,w,h,accent);
            String name = target.getName().getString(); if(name.length()>20) name=name.substring(0,19)+"…";
            c.drawText(mc.textRenderer,name,x+(int)(12*s),y+(int)(8*s),0xFFFFFFFF,true);
            float hp=Math.max(0,target.getHealth()), max=Math.max(1,target.getMaxHealth()), r=Math.min(1,hp/max);
            String hpText=String.format("%.1f / %.1f HP",hp,max);
            c.drawText(mc.textRenderer,hpText,x+(int)(12*s),y+(int)(23*s),0xFFD0D4DF,false);
            int bx=x+(int)(12*s), by=y+(int)(41*s), bw=w-(int)(24*s), bh=Math.max(4,(int)(7*s));
            c.fill(bx,by,bx+bw,by+bh,0xFF292D37); c.fill(bx,by,bx+(int)(bw*r),by+bh,accent);
            String d=String.format("%.1fm",mc.player.distanceTo(target));
            c.drawText(mc.textRenderer,d,x+w-(int)(12*s)-mc.textRenderer.getWidth(d),y+(int)(23*s),0xFF9AA1B1,false);
        }

        if (SettingsScreen.isEnabled("coordinates")) {
            String pos=String.format("XYZ  %d  %d  %d",mc.player.getBlockX(),mc.player.getBlockY(),mc.player.getBlockZ());
            small(c, pos, 10, sh-52, accent);
        }
        if (SettingsScreen.isEnabled("fps")) small(c,"FPS  "+MinecraftClient.getCurrentFps(),10,10,accent);
        if (SettingsScreen.isEnabled("ping")) {
            int ping=0; if(mc.getNetworkHandler()!=null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid())!=null) ping=mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency();
            small(c,"PING  "+ping+"ms",10,24,accent);
        }
        if (SettingsScreen.isEnabled("watermark")) small(c,"PULSE VISUALS",sw-82,10,accent);
        if (SettingsScreen.isEnabled("keystrokes")) drawKeys(c,mc,sw-118,sh-78,accent);
        if (SettingsScreen.isEnabled("armorHud")) drawArmor(c,mc,sw-118,sh-150,accent);
        if (SettingsScreen.isEnabled("crosshair")) drawCrosshair(c,mc,accent);
        if (SettingsScreen.isEnabled("lowHealth") && mc.player.getMaxHealth() > 0 && mc.player.getHealth()/mc.player.getMaxHealth()<0.25f) {
            int a=(int)(90+60*Math.sin(System.currentTimeMillis()/180.0)); c.fill(0,0,sw,3,(a<<24)); c.fill(0,sh-3,sw,sh,(a<<24));
        }
    }
    private static void card(DrawContext c,int x,int y,int w,int h,int accent){c.fill(x+4,y+5,x+w+4,y+h+5,0x66000000);c.fill(x,y,x+w,y+h,withAlpha(0xFF0E1118,SettingsScreen.opacity()));c.fill(x,y,x+3,y+h,accent);c.fill(x+3,y,x+w,y+2,accent);}
    private static int withAlpha(int rgb,float op){return ((int)(255*op)<<24)|(rgb&0xFFFFFF);}
    private static void small(DrawContext c,String t,int x,int y,int accent){MinecraftClient mc=MinecraftClient.getInstance();int w=mc.textRenderer.getWidth(t)+10;c.fill(x-4,y-3,x+w,y+10,0xB00A0D12);c.fill(x-4,y-3,x-2,y+10,accent);c.drawText(mc.textRenderer,t,x,y,0xFFFFFFFF,true);}
    private static void drawKeys(DrawContext c,MinecraftClient mc,int x,int y,int accent){String[] k={"W","A","S","D"};int[][] p={{1,0},{0,1},{1,1},{2,1}};for(int i=0;i<4;i++){int xx=x+p[i][0]*25,yy=y+p[i][1]*25;boolean on=pressed(mc,k[i]);c.fill(xx,yy,xx+22,yy+22,on?accent:0xB01A1D25);c.drawText(mc.textRenderer,k[i],xx+8,yy+7,0xFFFFFFFF,true);}}
    private static boolean pressed(MinecraftClient mc,String k){long w=mc.getWindow().getHandle();int key=switch(k){case"W"->87;case"A"->65;case"S"->83;default->68;};return org.lwjgl.glfw.GLFW.glfwGetKey(w,key)==org.lwjgl.glfw.GLFW.GLFW_PRESS;}
    private static void drawArmor(DrawContext c,MinecraftClient mc,int x,int y,int accent){int xx=x;for(int i=3;i>=0;i--){var st=mc.player.getInventory().getArmorStack(i);c.fill(xx,y,xx+24,y+24,0xB00D1016);if(!st.isEmpty())c.drawItem(st,xx+4,y+4);xx+=25;}c.fill(x,y+25,x+100,y+27,accent);}
    private static void drawCrosshair(DrawContext c,MinecraftClient mc,int accent){int x=mc.getWindow().getScaledWidth()/2,y=mc.getWindow().getScaledHeight()/2;c.fill(x-7,y-1,x-2,y+1,accent);c.fill(x+2,y-1,x+7,y+1,accent);c.fill(x-1,y-7,x+1,y-2,accent);c.fill(x-1,y+2,x+1,y+7,accent);}
}
