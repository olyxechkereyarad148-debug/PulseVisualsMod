package com.yourname.pulsevisuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class SettingsScreen extends Screen {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = MinecraftClient.getInstance().runDirectory.toPath().resolve("config/pulsevisuals.json");
    private static final Map<String, Boolean> TOGGLES = new LinkedHashMap<>();
    private static final Map<String, Double> SLIDERS = new LinkedHashMap<>();
    private static int accent = 0xFF9B6CFF;
    private static double scale = 1.0;
    private static double opacity = 0.92;
    private static int page = 0;

    static {
        defaults();
        load();
    }

    private static void defaults() {
        TOGGLES.clear();
        TOGGLES.put("targetHud", true);
        TOGGLES.put("damageNumbers", true);
        TOGGLES.put("trajectory", true);
        TOGGLES.put("autoEat", false);
        TOGGLES.put("coordinates", true);
        TOGGLES.put("fps", true);
        TOGGLES.put("ping", true);
        TOGGLES.put("armorHud", true);
        TOGGLES.put("keystrokes", true);
        TOGGLES.put("crosshair", true);
        TOGGLES.put("watermark", true);
        TOGGLES.put("lowHealth", true);
        SLIDERS.clear();
        SLIDERS.put("trajectoryLength", 40d);
        SLIDERS.put("autoEatThreshold", 8d);
        SLIDERS.put("hudScale", 1d);
        SLIDERS.put("hudOpacity", 0.92d);
    }

    public static boolean isEnabled(String key) { return TOGGLES.getOrDefault(key, false); }
    public static double getSlider(String key) { return SLIDERS.getOrDefault(key, 0d); }
    public static int accent() { return accent; }
    public static float opacity() { return (float) opacity; }
    public static float scale() { return (float) scale; }

    public SettingsScreen() { super(Text.literal("Pulse Visuals")); }

    private static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Config cfg = new Config();
            cfg.toggles = new LinkedHashMap<>(TOGGLES);
            cfg.sliders = new LinkedHashMap<>(SLIDERS);
            cfg.accent = accent; cfg.scale = scale; cfg.opacity = opacity;
            Files.writeString(FILE, GSON.toJson(cfg));
        } catch (IOException ignored) { }
    }

    private static void load() {
        try {
            if (!Files.exists(FILE)) return;
            Config cfg = GSON.fromJson(Files.readString(FILE), Config.class);
            if (cfg == null) return;
            if (cfg.toggles != null) TOGGLES.putAll(cfg.toggles);
            if (cfg.sliders != null) SLIDERS.putAll(cfg.sliders);
            accent = cfg.accent == 0 ? accent : cfg.accent;
            scale = clamp(cfg.scale == 0 ? 1 : cfg.scale, 0.7, 1.5);
            opacity = clamp(cfg.opacity == 0 ? .92 : cfg.opacity, .35, 1);
        } catch (Exception ignored) { }
    }

    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }

    @Override protected void init() {
        clearChildren();
        int panelW = 430, x = width / 2 - panelW / 2, y = 56;
        addDrawableChild(ButtonWidget.builder(Text.literal("VISUALS"), b -> { page = 0; init(); })
                .dimensions(x, 31, 105, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD"), b -> { page = 1; init(); })
                .dimensions(x + 110, 31, 105, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("STYLE"), b -> { page = 2; init(); })
                .dimensions(x + 220, 31, 105, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("RESET"), b -> { defaults(); save(); init(); })
                .dimensions(x + 330, 31, 100, 22).build());

        if (page == 0) {
            y = toggle(x, y, "targetHud", "Target HUD");
            y = toggle(x, y, "damageNumbers", "Damage Numbers");
            y = toggle(x, y, "trajectory", "Trajectory");
            y = toggle(x, y, "autoEat", "Auto Eat");
            y = toggle(x, y, "coordinates", "Coordinates");
            y = toggle(x, y, "fps", "FPS Counter");
            y = toggle(x, y, "ping", "Ping");
            y = toggle(x, y, "armorHud", "Armor HUD");
            y = toggle(x, y, "keystrokes", "Keystrokes");
            y = toggle(x, y, "crosshair", "Custom Crosshair");
            y = toggle(x, y, "watermark", "Pulse Watermark");
            toggle(x, y, "lowHealth", "Low Health Overlay");
        } else if (page == 1) {
            y = slider("hudScale", "HUD scale: %.2fx", .7, 1.5, x, y);
            y = slider("hudOpacity", "HUD opacity: %.0f%%", .35, 1, x, y);
            y += 8;
            y = slider("trajectoryLength", "Trajectory length: %.0f", 10, 80, x, y);
            slider("autoEatThreshold", "Auto Eat threshold: %.0f", 2, 20, x, y);
        } else {
            cButton(x, y, "Purple / Pulse", 0xFF9B6CFF); y += 27;
            cButton(x, y, "Cyan / Neon", 0xFF45D7FF); y += 27;
            cButton(x, y, "Red / Combat", 0xFFFF5C7A); y += 27;
            cButton(x, y, "Gold / Classic", 0xFFFFC857); y += 27;
            cButton(x, y, "Green / Toxic", 0xFF65E572); y += 42;
            addDrawableChild(ButtonWidget.builder(Text.literal("Save settings"), b -> save())
                    .dimensions(x + 110, y, 210, 24).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x + 145, 398, 140, 24).build());
    }

    private int toggle(int x, int y, String key, String label) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label + "  •  " + (isEnabled(key) ? "ON" : "OFF")), b -> {
            TOGGLES.put(key, !isEnabled(key)); save(); b.setMessage(Text.literal(label + "  •  " + (isEnabled(key) ? "ON" : "OFF")));
        }).dimensions(x, y, 430, 22).build());
        return y + 27;
    }

    private int slider(String key, String format, double min, double max, int x, int y) {
        double initial = (getSlider(key) - min) / (max - min);
        SliderWidget s = new SliderWidget(x, y, 430, 22, Text.literal(String.format(format, getSlider(key))), clamp(initial, 0, 1)) {
            @Override protected void updateMessage() { setMessage(Text.literal(String.format(format, min + (max - min) * value))); }
            @Override protected void applyValue() {
                SLIDERS.put(key, min + (max - min) * value);
                if (key.equals("hudScale")) scale = getSlider(key);
                if (key.equals("hudOpacity")) opacity = getSlider(key);
                save();
            }
        };
        addDrawableChild(s);
        return y + 29;
    }

    private void cButton(int x, int y, String label, int color) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> { accent = color; save(); })
                .dimensions(x, y, 430, 22).build());
    }

    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        renderBackground(c, mouseX, mouseY, delta);
        int w = 454, h = 430, x = width / 2 - w / 2, y = 4;
        c.fill(x + 5, y + 6, x + w + 5, y + h + 6, 0x66000000);
        c.fill(x, y, x + w, y + h, 0xF20B0E14);
        c.fill(x, y, x + w, y + 3, accent);
        c.fill(x, y + 3, x + 3, y + h, accent);
        c.drawText(textRenderer, "PULSE VISUALS", x + 12, y + 10, 0xFFFFFFFF, true);
        c.drawText(textRenderer, "1.21.11  •  PvP visual suite", x + 12, y + 23, 0xFF9AA1B1, false);
        super.render(c, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }

    private static final class Config {
        Map<String, Boolean> toggles;
        Map<String, Double> sliders;
        int accent;
        double scale;
        double opacity;
    }
}
