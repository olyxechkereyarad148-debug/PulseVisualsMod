package com.yourname.pulsevisuals;

/** Trajectory simulation toggle is kept as a feature flag for future world-line rendering. */
public final class TrajectoryRenderer { private TrajectoryRenderer() {} public static void register() {} }
