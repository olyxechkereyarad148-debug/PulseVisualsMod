# Pulse Visuals 1.1.0

A client-side Fabric PvP visual suite for Minecraft 1.21.11.

## HUD features
- Target HUD with health and distance
- FPS and ping
- XYZ coordinates
- Armor HUD
- W/A/S/D keystrokes
- Custom crosshair
- Pulse watermark
- Low-health pulse overlay
- Damage numbers
- Auto Eat
- Trajectory feature flag

## Customization
- Visual/HUD/Style tabs
- Per-feature toggles
- HUD scale and opacity
- Five accent presets
- Persistent settings in `config/pulsevisuals.json`
- Right Shift opens the menu

## Build
Use Java 21 and Fabric Loom. GitHub Actions builds `build/libs/pulsevisuals-1.1.0.jar`.
