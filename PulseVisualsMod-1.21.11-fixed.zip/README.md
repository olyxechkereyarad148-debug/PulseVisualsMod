# Pulse Visuals Mod

Fabric 1.21.11 client mod.

- Right Shift opens settings.
- GitHub Actions builds the JAR automatically.
- Updated for Fabric API 0.141.3+1.21.11 / Yarn 1.21.11+build.4.
