package com.yourname.pulsevisuals;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import java.util.LinkedHashMap;
import java.util.Map;
public class SettingsScreen extends Screen {
 private static final Map<String,Boolean>T=new LinkedHashMap<>(); private static final Map<String,Double>S=new LinkedHashMap<>();
 static{T.put("targetHud",true);T.put("damageNumbers",true);T.put("trajectory",true);T.put("autoEat",false);T.put("pvpSave",true);S.put("trajectoryLength",40d);S.put("autoEatThreshold",6d);}
 public static boolean isEnabled(String k){return T.getOrDefault(k,false);} public static double getSlider(String k){return S.getOrDefault(k,0d);}
 public SettingsScreen(){super(Text.literal("Pulse Visuals — Settings"));}
 protected void init(){int x=width/2-110,y=25;addDrawableChild(ButtonWidget.builder(Text.literal("Pulse Visuals"),b->{}).dimensions(x,y,220,20).build());y+=28;y=toggle("targetHud","Target HUD",x,y);y=toggle("damageNumbers","Damage Numbers",x,y);y=toggle("trajectory","Trajectory",x,y);y=toggle("autoEat","Auto Eat",x,y);y=toggle("pvpSave","PvP Save",x,y);y+=8;y=slider("trajectoryLength","Trajectory length: %.0f",10,80,x,y);y=slider("autoEatThreshold","Food threshold: %.0f",2,20,x,y);addDrawableChild(ButtonWidget.builder(Text.literal("Close"),b->closeScreen()).dimensions(x+60,y+12,100,20).build());}
 private int toggle(String k,String l,int x,int y){addDrawableChild(ButtonWidget.builder(Text.literal(l+": "+(isEnabled(k)?"ON":"OFF")),b->{T.put(k,!isEnabled(k));b.setMessage(Text.literal(l+": "+(isEnabled(k)?"ON":"OFF")));}).dimensions(x,y,220,20).build());return y+24;}
 private int slider(String k,String f,double min,double max,int x,int y){double init=(getSlider(k)-min)/(max-min);SliderWidget s=new SliderWidget(x,y,220,20,Text.literal(String.format(f,getSlider(k))),init){protected void updateMessage(){double v=min+(max-min)*value;setMessage(Text.literal(String.format(f,v)));}protected void applyValue(){S.put(k,min+(max-min)*value);}};addDrawableChild(s);return y+24;}
 public void render(DrawContext c,int mx,int my,float d){renderBackground(c,mx,my,d);super.render(c,mx,my,d);} public boolean shouldPause(){return false;} private void closeScreen(){close();}
}