package com.yourname.pulsevisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.lwjgl.glfw.GLFW;

public final class PulseVisualsMod implements ClientModInitializer {
    private static boolean menuLatch;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register(new TargetHudRenderer());
        HudRenderCallback.EVENT.register(new DamageParticle.HudRenderer());
        ClientTickEvents.END_CLIENT_TICK.register(new AfkUtils());
        DamageTracker.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.currentScreen != null) {
                menuLatch = false;
                return;
            }

            boolean down = GLFW.glfwGetKey(
                    client.getWindow().getHandle(),
                    GLFW.GLFW_KEY_RIGHT_SHIFT
            ) == GLFW.GLFW_PRESS;

            if (down && !menuLatch) {
                client.setScreen(new SettingsScreen());
            }
            menuLatch = down;
        });
    }
}
