# Pulse Visuals — Minecraft 1.21.11

Client-side Fabric mod with customizable PvP HUD.

## Build

GitHub Actions builds the remapped JAR directly from source. The old `Check fixed JAR` step is intentionally removed: it caused failures when the fixed JAR was missing or stale.

Artifact: `pulsevisuals-1.1.1.jar`

## HUD

Right Shift opens the Pulse Visuals menu. It includes Target HUD, damage numbers, trajectory toggle, Auto Eat, coordinates, FPS, ping, armor HUD, keystrokes, custom crosshair, watermark, low-health overlay, scale, opacity and accent themes.

Minecraft 1.21.11 / Fabric Loader 0.19.3 / Java 21.
