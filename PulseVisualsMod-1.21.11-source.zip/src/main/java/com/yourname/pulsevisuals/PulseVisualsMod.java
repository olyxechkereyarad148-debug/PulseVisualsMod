package com.yourname.pulsevisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class PulseVisualsMod implements ClientModInitializer {
    public static final String MOD_ID = "pulsevisuals";
    public static KeyBinding openSettingsKey;
    public static KeyBinding emotionsKey;
    private static boolean lastAttack;
    private static boolean lastUse;

    @Override
    public void onInitializeClient() {
        openSettingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pulsevisuals.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, KeyBinding.Category.MISC));
        emotionsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pulsevisuals.emotions", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, KeyBinding.Category.MISC));

        PulseHud.register();
        ClientTickEvents.END_CLIENT_TICK.register(PulseVisualsMod::tick);
    }

    private static void tick(MinecraftClient client) {
        if (openSettingsKey.wasPressed()) client.setScreen(new SettingsScreen());
        if (emotionsKey.wasPressed()) client.setScreen(new EmotionsScreen());

        boolean attack = client.options.attackKey.isPressed();
        boolean use = client.options.useKey.isPressed();
        if (attack && !lastAttack) PulseHud.registerClick(true);
        if (use && !lastUse) PulseHud.registerClick(false);
        lastAttack = attack;
        lastUse = use;
        PulseHud.tick(client);
    }
}
