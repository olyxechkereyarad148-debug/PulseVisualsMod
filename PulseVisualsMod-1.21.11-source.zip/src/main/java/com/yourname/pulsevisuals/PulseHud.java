package com.yourname.pulsevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayDeque;
import java.util.Deque;

public final class PulseHud {
    private static final Identifier HUD_ID = Identifier.of(PulseVisualsMod.MOD_ID, "hud");
    private static final Deque<Long> LEFT = new ArrayDeque<>();
    private static final Deque<Long> RIGHT = new ArrayDeque<>();
    private static int bps;

    private PulseHud() {}

    public static void register() {
        HudElementRegistry.addLast(HUD_ID, PulseHud::render);
    }

    public static void registerClick(boolean left) {
        (left ? LEFT : RIGHT).addLast(System.currentTimeMillis());
    }

    public static void tick(MinecraftClient client) {
        long now = System.currentTimeMillis();
        while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000) LEFT.removeFirst();
        while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000) RIGHT.removeFirst();
        if (client.player != null) bps = (int)Math.round(client.player.getVelocity().horizontalLength() * 20.0);
    }

    private static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || !SettingsScreen.isHudEnabled()) return;

        int x = 8, y = 8;
        if (SettingsScreen.fps()) { line(context, client, "FPS: " + client.getCurrentFps(), x, y); y += 12; }
        if (SettingsScreen.cps()) { line(context, client, "CPS: " + LEFT.size() + " | " + RIGHT.size(), x, y); y += 12; }
        if (SettingsScreen.bps()) { line(context, client, "BPS: " + bps, x, y); y += 12; }
        if (SettingsScreen.ping()) {
            int ping = getPing(client.player);
            line(context, client, "Ping: " + (ping < 0 ? "--" : ping) + " ms", x, y); y += 12;
        }
        if (SettingsScreen.coords()) {
            line(context, client, String.format("XYZ: %.1f %.1f %.1f",
                    client.player.getX(), client.player.getY(), client.player.getZ()), x, y); y += 12;
        }

        if (SettingsScreen.keystrokes()) {
            int kx = x, ky = y + 6;
            key(context, client, "W", kx + 18, ky);
            key(context, client, "A", kx, ky + 18);
            key(context, client, "S", kx + 18, ky + 18);
            key(context, client, "D", kx + 36, ky + 18);
            y += 54;
        }

        if (SettingsScreen.armor()) {
            int i = 0;
            for (var stack : client.player.getInventory().getArmorStacks()) {
                if (!stack.isEmpty()) {
                    context.drawItem(stack, x + i * 20, y);
                    context.drawItemInSlot(client.textRenderer, stack, x + i * 20, y);
                }
                i++;
            }
            y += 22;
        }

        if (SettingsScreen.targetHud() && client.targetedEntity instanceof LivingEntity living) {
            line(context, client, "Target: " + living.getName().getString()
                    + String.format(" %.1f HP", living.getHealth()), x, y);
        }
    }

    private static void line(DrawContext c, MinecraftClient m, String s, int x, int y) {
        c.drawTextWithShadow(m.textRenderer, Text.literal(s), x, y, 0xFFFFFFFF);
    }

    private static void key(DrawContext c, MinecraftClient m, String s, int x, int y) {
        c.fill(x, y, x + 16, y + 16, 0xAA20252E);
        c.drawCenteredTextWithShadow(m.textRenderer, Text.literal(s), x + 8, y + 4, 0xFFFFFFFF);
    }

    private static int getPing(PlayerEntity p) {
        if (p.networkHandler == null) return -1;
        var entry = p.networkHandler.getPlayerListEntry(p.getUuid());
        return entry == null ? -1 : entry.getLatency();
    }
}
