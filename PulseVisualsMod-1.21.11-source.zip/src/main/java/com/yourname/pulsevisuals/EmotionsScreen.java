package com.yourname.pulsevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class EmotionsScreen extends Screen {
    public EmotionsScreen(){super(Text.literal("Pulse Emotions"));}

    @Override protected void init(){
        int x=width/2-45, y=height/2-55;
        addButton(x,y,"Wave"); y+=28;
        addButton(x,y,"Dance"); y+=28;
        addButton(x,y,"Pose"); y+=35;
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"),b->close())
                .dimensions(x,y,90,20).build());
    }

    private void addButton(int x,int y,String name){
        addDrawableChild(ButtonWidget.builder(Text.literal(name),b->{
            if(client!=null && client.player!=null)
                client.player.sendMessage(Text.literal("Pulse: "+name),true);
        }).dimensions(x,y,90,20).build());
    }

    private void close(){if(client!=null)client.setScreen(null);}

    @Override public void render(DrawContext c,int mouseX,int mouseY,float delta){
        c.fill(0,0,width,height,0xE914171C);
        c.drawCenteredTextWithShadow(textRenderer,Text.literal("Pulse Emotions"),width/2,18,0xFFFFFFFF);
        super.render(c,mouseX,mouseY,delta);
    }
}
