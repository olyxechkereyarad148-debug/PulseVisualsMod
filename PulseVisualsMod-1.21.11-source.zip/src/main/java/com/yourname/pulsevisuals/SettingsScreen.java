package com.yourname.pulsevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class SettingsScreen extends Screen {
    private static boolean hud=true, fps=true, cps=true, bps=true, ping=true;
    private static boolean coords=true, keystrokes=true, armor=true, targetHud=true;

    public SettingsScreen() { super(Text.literal("Pulse Visuals")); }

    public static boolean isHudEnabled(){return hud;}
    public static boolean fps(){return fps;}
    public static boolean cps(){return cps;}
    public static boolean bps(){return bps;}
    public static boolean ping(){return ping;}
    public static boolean coords(){return coords;}
    public static boolean keystrokes(){return keystrokes;}
    public static boolean armor(){return armor;}
    public static boolean targetHud(){return targetHud;}

    @Override protected void init() {
        int x=width/2-100, y=45;
        add(x,y,"HUD",()->hud=!hud); y+=23;
        add(x,y,"FPS",()->fps=!fps); y+=23;
        add(x,y,"CPS",()->cps=!cps); y+=23;
        add(x,y,"BPS",()->bps=!bps); y+=23;
        add(x,y,"Ping",()->ping=!ping); y+=23;
        add(x,y,"Coordinates",()->coords=!coords); y+=23;
        add(x,y,"Keystrokes",()->keystrokes=!keystrokes); y+=23;
        add(x,y,"Armor Status",()->armor=!armor); y+=23;
        add(x,y,"Target HUD",()->targetHud=!targetHud); y+=30;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b->close())
                .dimensions(x,y,200,20).build());
    }

    private void add(int x,int y,String name,Runnable action){
        addDrawableChild(ButtonWidget.builder(Text.literal(name+": "+(enabled(name)?"ON":"OFF")), b->{
            action.run();
            b.setMessage(Text.literal(name+": "+(enabled(name)?"ON":"OFF")));
        }).dimensions(x,y,200,20).build());
    }

    private boolean enabled(String n){
        return switch(n){
            case "HUD"->hud; case "FPS"->fps; case "CPS"->cps; case "BPS"->bps;
            case "Ping"->ping; case "Coordinates"->coords; case "Keystrokes"->keystrokes;
            case "Armor Status"->armor; case "Target HUD"->targetHud; default->false;
        };
    }

    private void close(){ if(client!=null) client.setScreen(null); }

    @Override public void render(DrawContext c,int mouseX,int mouseY,float delta){
        c.fill(0,0,width,height,0xE914171C);
        c.drawCenteredTextWithShadow(textRenderer,Text.literal("Pulse Visuals"),width/2,18,0xFFFFFFFF);
        super.render(c,mouseX,mouseY,delta);
    }
}
