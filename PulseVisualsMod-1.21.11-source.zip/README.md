# Pulse Visuals
Fabric client mod for Minecraft 1.21.11.

Keys:
- O — settings
- B — emotions

This version intentionally has no mixin configuration, so the old `disconnect(Screen)` mixin crash is removed.
