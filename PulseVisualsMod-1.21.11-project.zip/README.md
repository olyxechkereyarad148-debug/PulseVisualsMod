# Pulse Visuals Mod

Fabric 1.21.11 client mod. Right Shift opens settings. GitHub Actions builds the JAR automatically.
