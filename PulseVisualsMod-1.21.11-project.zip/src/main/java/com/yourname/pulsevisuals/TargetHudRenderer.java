package com.yourname.pulsevisuals;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.client.render.RenderTickCounter;
public class TargetHudRenderer implements HudRenderCallback {
 public void onHudRender(DrawContext c,RenderTickCounter t){if(!SettingsScreen.isEnabled("targetHud"))return;MinecraftClient m=MinecraftClient.getInstance();if(m.player==null||m.world==null)return;if(!(m.crosshairTarget instanceof EntityHitResult h)||!(h.getEntity() instanceof LivingEntity e))return;int x=m.getWindow().getScaledWidth()/2+45,y=m.getWindow().getScaledHeight()/2-35;float hp=Math.max(0,e.getHealth()),max=Math.max(1,e.getMaxHealth());int bar=(int)(100*hp/max);c.fill(x-5,y-5,x+125,y+38,0xAA111111);c.drawText(m.textRenderer,e.getName(),x,y,0xFFFFFFFF,true);c.drawText(m.textRenderer,String.format("❤ %.1f / %.1f",hp,max),x,y+12,0xFFFF5555,true);c.fill(x,y+27,x+100,y+31,0xFF333333);c.fill(x,y+27,x+bar,y+31,0xFFFF3333);}
}