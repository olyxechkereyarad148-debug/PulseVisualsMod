package com.yourname.pulsevisuals;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import org.lwjgl.glfw.GLFW;
public class PulseVisualsMod implements ModInitializer {
 public static boolean menuOpen;
 public void onInitialize(){
  HudRenderCallback.EVENT.register(new TargetHudRenderer());
  HudRenderCallback.EVENT.register(new DamageParticle.HudRenderer());
  WorldRenderEvents.LAST.register(new TrajectoryRenderer());
  ClientTickEvents.END_CLIENT_TICK.register(new AfkUtils());
  DamageTracker.init();
  ClientTickEvents.END_CLIENT_TICK.register(c->{if(c.player==null||c.currentScreen!=null)return; long w=c.getWindow().getHandle(); boolean p=GLFW.glfwGetKey(w,GLFW.GLFW_KEY_RIGHT_SHIFT)==GLFW.GLFW_PRESS; if(p&&!menuOpen){menuOpen=true;c.setScreen(new SettingsScreen());}else if(!p)menuOpen=false;});
 }
}