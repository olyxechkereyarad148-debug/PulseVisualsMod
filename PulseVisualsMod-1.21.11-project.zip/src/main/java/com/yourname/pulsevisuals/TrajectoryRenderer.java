package com.yourname.pulsevisuals;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
public class TrajectoryRenderer implements WorldRenderEvents.Last {
 public void onLast(WorldRenderContext c){if(!SettingsScreen.isEnabled("trajectory"))return;MinecraftClient m=MinecraftClient.getInstance();if(m.player==null||m.world==null||!m.player.isUsingItem())return;int n=(int)SettingsScreen.getSlider("trajectoryLength");Vec3d p=m.player.getEyePos(),v=m.player.getRotationVector().multiply(1.5);for(int i=0;i<n;i++){v=v.add(0,-.05,0);p=p.add(v);}}
}