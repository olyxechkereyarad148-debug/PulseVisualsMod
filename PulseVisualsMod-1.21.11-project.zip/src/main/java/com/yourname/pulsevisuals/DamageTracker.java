package com.yourname.pulsevisuals;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.entity.attribute.EntityAttributes;
public class DamageTracker {
 public static void init(){AttackEntityCallback.EVENT.register((p,w,h,e,r)->{if(!SettingsScreen.isEnabled("damageNumbers")||!(e instanceof LivingEntity l))return ActionResult.PASS;float d=(float)Math.max(0,p.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE));if(d>0)DamageParticle.spawn(l.getPos().add(0,l.getHeight()+.2,0),d);return ActionResult.PASS;});}
}