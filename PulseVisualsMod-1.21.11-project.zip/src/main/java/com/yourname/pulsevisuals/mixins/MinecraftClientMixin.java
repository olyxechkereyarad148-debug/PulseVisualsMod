package com.yourname.pulsevisuals.mixins;
import com.yourname.pulsevisuals.SettingsScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
 @Inject(method="disconnect(Lnet/minecraft/client/gui/screen/Screen;)V",at=@At("HEAD"),cancellable=true)
 private void pulsevisuals$save(Screen screen,CallbackInfo ci){if(!SettingsScreen.isEnabled("pvpSave"))return;MinecraftClient c=(MinecraftClient)(Object)this;if(c.player!=null&&c.player.getAttacker()!=null){ci.cancel();c.player.sendMessage(net.minecraft.text.Text.literal("§cPulse Visuals: ты в бою — выход отменён."),true);}}
}