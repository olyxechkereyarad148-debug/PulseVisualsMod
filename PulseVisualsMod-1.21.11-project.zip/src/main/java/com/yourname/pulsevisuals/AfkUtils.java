package com.yourname.pulsevisuals;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
public class AfkUtils implements ClientTickEvents.EndTick {
 int cd;
 public void onEndTick(MinecraftClient m){if(!SettingsScreen.isEnabled("autoEat")||m.player==null||m.interactionManager==null)return;if(cd>0){cd--;return;}if(m.player.getHungerManager().getFoodLevel()>(int)SettingsScreen.getSlider("autoEatThreshold")||m.player.isUsingItem())return;int slot=-1;for(int i=0;i<9;i++){ItemStack s=m.player.getInventory().getStack(i);if(!s.isEmpty()&&s.getItem().isFood()){slot=i;break;}}if(slot<0)return;int old=m.player.getInventory().getSelectedSlot();m.player.getInventory().setSelectedSlot(slot);m.interactionManager.interactItem(m.player,Hand.MAIN_HAND);m.player.getInventory().setSelectedSlot(old);cd=20;}
}