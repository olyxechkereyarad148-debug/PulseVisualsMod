# Pulse Visuals

Fabric client mod for Minecraft 1.21.11.

This version removes the incompatible MinecraftClient disconnect mixin that caused startup crashes and builds the checked-in Gradle project directly in GitHub Actions.
