package com.yourname.pulsevisuals;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.ActionResult;

public final class DamageTracker {
    private DamageTracker() {}

    public static void init() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!SettingsScreen.isEnabled("damageNumbers") || !(entity instanceof LivingEntity living)) {
                return ActionResult.PASS;
            }

            float damage = (float) Math.max(
                    0.0,
                    player.getAttributeValue(EntityAttributes.ATTACK_DAMAGE)
            );

            if (damage > 0.0f) {
                DamageParticle.spawn(
                        living.getEntityPos().add(0.0, living.getHeight() + 0.2, 0.0),
                        damage
                );
            }

            return ActionResult.PASS;
        });
    }
}
