package com.yourname.pulsevisuals;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import java.util.concurrent.CopyOnWriteArrayList;
public class DamageParticle {
 static final CopyOnWriteArrayList<DamageParticle>A=new CopyOnWriteArrayList<>(); final Vec3d pos;final String text;int age;
 private DamageParticle(Vec3d p,float d){pos=p;text=String.format("-%.1f",d);} public static void spawn(Vec3d p,float d){A.add(new DamageParticle(p,d));}
 public static class HudRenderer implements HudRenderCallback{public void onHudRender(DrawContext c,RenderTickCounter t){if(!SettingsScreen.isEnabled("damageNumbers"))return;MinecraftClient m=MinecraftClient.getInstance();if(m.player==null)return;for(DamageParticle p:A){if(++p.age>=25){A.remove(p);continue;}int x=m.getWindow().getScaledWidth()/2+12,y=m.getWindow().getScaledHeight()/2-55-p.age;c.drawText(m.textRenderer,Text.literal(p.text),x,y,0xFFFF5555,true);}}}
}