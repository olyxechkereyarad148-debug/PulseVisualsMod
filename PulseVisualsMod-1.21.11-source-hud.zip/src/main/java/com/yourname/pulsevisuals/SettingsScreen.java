package com.yourname.pulsevisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.LinkedHashMap;
import java.util.Map;

/** In-game Pulse Visuals control panel. */
public final class SettingsScreen extends Screen {
    private static final Map<String, Boolean> TOGGLES = new LinkedHashMap<>();
    private static final Map<String, Double> SLIDERS = new LinkedHashMap<>();

    static {
        TOGGLES.put("targetHud", true);
        TOGGLES.put("damageNumbers", true);
        TOGGLES.put("trajectory", true);
        TOGGLES.put("autoEat", false);
        TOGGLES.put("pvpSave", true);
        SLIDERS.put("trajectoryLength", 40d);
        SLIDERS.put("autoEatThreshold", 6d);
    }

    public static boolean isEnabled(String key) { return TOGGLES.getOrDefault(key, false); }
    public static double getSlider(String key) { return SLIDERS.getOrDefault(key, 0d); }

    public SettingsScreen() { super(Text.literal("Pulse Visuals")); }

    @Override
    protected void init() {
        clearChildren();
        int panelW = 300;
        int x = width / 2 - panelW / 2;
        int y = Math.max(36, height / 2 - 112);

        addDrawableChild(ButtonWidget.builder(Text.literal("Target HUD  •  " + state("targetHud")), b -> flip(b, "targetHud", "Target HUD"))
                .dimensions(x + 20, y, 260, 22).build());
        y += 27;
        addDrawableChild(ButtonWidget.builder(Text.literal("Damage Numbers  •  " + state("damageNumbers")), b -> flip(b, "damageNumbers", "Damage Numbers"))
                .dimensions(x + 20, y, 260, 22).build());
        y += 27;
        addDrawableChild(ButtonWidget.builder(Text.literal("Trajectory  •  " + state("trajectory")), b -> flip(b, "trajectory", "Trajectory"))
                .dimensions(x + 20, y, 260, 22).build());
        y += 27;
        addDrawableChild(ButtonWidget.builder(Text.literal("Auto Eat  •  " + state("autoEat")), b -> flip(b, "autoEat", "Auto Eat"))
                .dimensions(x + 20, y, 260, 22).build());
        y += 34;
        y = slider("trajectoryLength", "Trajectory length: %.0f", 10, 80, x + 20, y);
        y = slider("autoEatThreshold", "Food threshold: %.0f", 2, 20, x + 20, y);
        y += 8;
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x + 90, y, 120, 22).build());
    }

    private String state(String key) { return isEnabled(key) ? "ON" : "OFF"; }

    private void flip(ButtonWidget button, String key, String label) {
        boolean value = !isEnabled(key);
        TOGGLES.put(key, value);
        button.setMessage(Text.literal(label + "  •  " + (value ? "ON" : "OFF")));
    }

    private int slider(String key, String format, double min, double max, int x, int y) {
        double initial = (getSlider(key) - min) / (max - min);
        SliderWidget slider = new SliderWidget(x, y, 260, 22,
                Text.literal(String.format(format, getSlider(key))), initial) {
            @Override protected void updateMessage() {
                double v = min + (max - min) * value;
                setMessage(Text.literal(String.format(format, v)));
            }
            @Override protected void applyValue() {
                SLIDERS.put(key, min + (max - min) * value);
            }
        };
        addDrawableChild(slider);
        return y + 27;
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        renderBackground(c, mouseX, mouseY, delta);

        int panelW = 300;
        int panelH = 270;
        int x = width / 2 - panelW / 2;
        int y = height / 2 - panelH / 2;

        c.fill(x + 4, y + 5, x + panelW + 4, y + panelH + 5, 0x66000000);
        c.fill(x, y, x + panelW, y + panelH, 0xF20F1117);
        c.fill(x, y, x + panelW, y + 2, 0xFF8B5CF6);
        c.fill(x, y + 2, x + 3, y + panelH, 0xFF8B5CF6);

        c.drawText(textRenderer, "PULSE VISUALS", x + 20, y + 15, 0xFFFFFFFF, true);
        c.drawText(textRenderer, "PvP visual settings", x + 20, y + 29, 0xFF8F95A3, false);
        c.drawText(textRenderer, "Right Shift", x + panelW - 78, y + 15, 0xFF8B5CF6, false);

        super.render(c, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }
}
