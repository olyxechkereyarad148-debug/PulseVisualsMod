package com.yourname.pulsevisuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

public class AfkUtils implements ClientTickEvents.EndTick {
    private int cooldown;

    @Override
    public void onEndTick(MinecraftClient client) {
        if (!SettingsScreen.isEnabled("autoEat")
                || client.player == null
                || client.interactionManager == null) {
            return;
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        if (client.player.getHungerManager().getFoodLevel()
                > (int) SettingsScreen.getSlider("autoEatThreshold")
                || client.player.isUsingItem()) {
            return;
        }

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.contains(DataComponentTypes.FOOD)) {
                slot = i;
                break;
            }
        }

        if (slot < 0) return;

        int oldSlot = client.player.getInventory().getSelectedSlot();
        client.player.getInventory().setSelectedSlot(slot);
        client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
        client.player.getInventory().setSelectedSlot(oldSlot);
        cooldown = 20;
    }
}
