package com.yourname.pulsevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Clean PvP target card: compact, readable and unobtrusive. */
public final class TargetHudRenderer implements HudRenderCallback {
    @Override
    public void onHudRender(DrawContext c, RenderTickCounter tickCounter) {
        if (!SettingsScreen.isEnabled("targetHud")) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof LivingEntity target)) return;
        if (target == mc.player) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        int w = 190;
        int h = 58;
        int x = sw / 2 + 34;
        int y = sh / 2 - 42;

        // Shadow + layered glass-style card.
        c.fill(x + 3, y + 3, x + w + 3, y + h + 3, 0x66000000);
        c.fill(x, y, x + w, y + h, 0xE9101218);
        c.fill(x, y, x + 3, y + h, 0xFF8B5CF6);
        c.fill(x + 3, y, x + w, y + 1, 0xFF2B2F3A);
        c.fill(x + 3, y + h - 1, x + w, y + h, 0xFF171922);

        String name = target.getName().getString();
        if (name.length() > 20) name = name.substring(0, 19) + "…";

        c.drawText(mc.textRenderer, name, x + 12, y + 8, 0xFFFFFFFF, true);

        float hp = Math.max(0.0f, target.getHealth());
        float maxHp = Math.max(1.0f, target.getMaxHealth());
        float ratio = Math.min(1.0f, hp / maxHp);

        String hpText = String.format("%.1f / %.1f HP", hp, maxHp);
        c.drawText(mc.textRenderer, hpText, x + 12, y + 21, 0xFFB9BDC9, false);

        int barX = x + 12;
        int barY = y + 36;
        int barW = w - 24;
        c.fill(barX, barY, barX + barW, barY + 6, 0xFF292D37);
        if (ratio > 0) {
            int fill = Math.max(1, (int) (barW * ratio));
            c.fill(barX, barY, barX + fill, barY + 6, 0xFF8B5CF6);
            if (fill > 2) c.fill(barX + 2, barY + 1, barX + fill, barY + 2, 0xFFB79CFF);
        }

        double distance = mc.player.distanceTo(target);
        String dist = String.format("%.1fm", distance);
        c.drawText(mc.textRenderer, dist, x + w - 12 - mc.textRenderer.getWidth(dist), y + 21, 0xFF8F95A3, false);
    }
}
