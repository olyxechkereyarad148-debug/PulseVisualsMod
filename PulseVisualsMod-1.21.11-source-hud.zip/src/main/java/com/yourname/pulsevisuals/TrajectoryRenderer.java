package com.yourname.pulsevisuals;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public final class TrajectoryRenderer {
    private TrajectoryRenderer() {}

    public static void register() {
        WorldRenderEvents.END_MAIN.register(TrajectoryRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        if (!SettingsScreen.isEnabled("trajectory")) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || !client.player.isUsingItem()) return;

        int length = (int) SettingsScreen.getSlider("trajectoryLength");
        Vec3d position = client.player.getEyePos();
        Vec3d velocity = client.player.getRotationVector().multiply(1.5);

        // Keep the trajectory simulation here; actual line rendering can be
        // added using context.matrices()/consumers() without relying on the
        // removed pre-1.21.11 WorldRenderEvents.Last API.
        for (int i = 0; i < length; i++) {
            velocity = velocity.add(0.0, -0.05, 0.0);
            position = position.add(velocity);
        }
    }
}
